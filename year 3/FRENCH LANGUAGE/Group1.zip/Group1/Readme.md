**Delivery Records System**

1\. Database Setup First, you need to create the database and the required collections manually (or let the script do it if using a full seed script).



Database Name: deliveryrecordsDB 



Collections to Create:

customers 

deliveries 

orders 

riders









Run in terminal:
mongosh "mongodb://localhost:27017/deliveryrecordsDB" commands.js



change the localhost:27017 to your own connection

