// NoSQL Data Model
// use deliveryrecordsDB

// customers collection
db.customers.insertMany([
  {
    "_id": ObjectId("695dee7b10db6666ca9b529c"),
    "customerName": "Ng Yu Hin",
    "email": "ngyuhin@gmail.com",
    "phoneNumbers": ["0123456789", "0198765432"],
    "address": { "street": "Jalan Universiti", "city": "Skudai", "state": "Johor", "postcode": "81310" },
    "registeredDate": ISODate("2024-11-15T00:00:00.000Z")
  },
  {
    "_id": ObjectId("695deed010db6666ca9b529d"),
    "customerName": "Elijah She",
    "email": "elijahshe@gmail.com",
    "phoneNumbers": ["0120987652", "0146282914"],
    "address": { "street": "Jalan Permas", "city": "Permas Jaya", "state": "Johor", "postcode": "81110" },
    "registeredDate": ISODate("2024-11-15T00:00:00.000Z")
  },
  {
    "_id": ObjectId("695def1f10db6666ca9b529e"),
    "customerName": "Tan Zhi Ming",
    "email": "tanzhiming@gmail.com",
    "phoneNumbers": ["0167983654", "0136252964"],
    "address": { "street": "Jalan Muar", "city": "Muar", "state": "Johor", "postcode": "84060" },
    "registeredDate": ISODate("2024-11-15T00:00:00.000Z")
  },
  {
    "_id": ObjectId("695def6510db6666ca9b529f"),
    "customerName": "Chau Ying Jia",
    "email": "chauyingjia@gmail.com",
    "phoneNumbers": ["0174892749", "0120592759"],
    "address": { "street": "Jalan Universiti", "city": "Skudai", "state": "Johor", "postcode": "84060" },
    "registeredDate": ISODate("2024-11-15T00:00:00.000Z")
  }
]);

// orders collection
db.orders.insertMany([
  {
    "_id": ObjectId("75c3c3c3c3c3c3c3c3c3c3c3"),
    "customerId": ObjectId("65a1f1a1a1a1a1a1a1a1a1a1"),
    "items": [
      { "itemName": "Chicken Burger", "quantity": 2, "price": 8.5 },
      { "itemName": "Coke", "quantity": 1, "price": 2.5 }
    ],
    "totalAmount": 19.5,
    "payment": { "method": "E-Wallet", "status": "Paid" },
    "orderDate": ISODate("2025-01-02T12:45:00.000Z")
  },
  {
    "_id": ObjectId("75c3c3c3c3c3c3c3c3c3c3c4"),
    "customerId": ObjectId("65a1f1a1a1a1a1a1a1a1a1a2"),
    "items": [
      { "itemName": "Beef Burger", "quantity": 1, "price": 10 },
      { "itemName": "Fries", "quantity": 1, "price": 4 }
    ],
    "totalAmount": 14,
    "payment": { "method": "Cash", "status": "Paid" },
    "orderDate": ISODate("2025-01-03T09:00:00.000Z")
  },
  {
    "_id": ObjectId("75c3c3c3c3c3c3c3c3c3c3c5"),
    "customerId": ObjectId("65a1f1a1a1a1a1a1a1a1a1a3"),
    "items": [
      { "itemName": "Veggie Pizza", "quantity": 1, "price": 12.5 },
      { "itemName": "Orange Juice", "quantity": 2, "price": 3 }
    ],
    "totalAmount": 18.5,
    "payment": { "method": "Credit Card", "status": "Paid" },
    "orderDate": ISODate("2025-01-02T11:00:00.000Z")
  },
  {
    "_id": ObjectId("75c3c3c3c3c3c3c3c3c3c3c6"),
    "customerId": ObjectId("65a1f1a1a1a1a1a1a1a1a1a4"),
    "items": [
      { "itemName": "Spaghetti Carbonara", "quantity": 1, "price": 11 },
      { "itemName": "Garlic Bread", "quantity": 1, "price": 3.5 }
    ],
    "totalAmount": 14.5,
    "payment": { "method": "E-Wallet", "status": "Paid" },
    "orderDate": ISODate("2025-01-06T09:00:00.000Z")
  }
]);

// deliveries collection
db.deliveries.insertMany([
  {
    "_id": ObjectId("695df18e10db6666ca9b52ae"),
    "orderId": ObjectId("65c3c3c3c3c3c3c3c3c3c3c3"),
    "riderId": ObjectId("65b2f2b2b2b2b2b2b2b2b2b2"),
    "deliveryStatus": [
      { "status": "Processing", "timestamp": ISODate("2025-01-02T13:09:55.000Z") },
      { "status": "Picked Up", "timestamp": ISODate("2025-01-02T13:10:00.000Z") },
      { "status": "Out for Delivery", "timestamp": ISODate("2025-01-02T13:30:00.000Z") }
    ],
    "currentStatus": "Out for Delivery",
    "estimatedArrival": ISODate("2025-01-02T14:00:00.000Z")
  },
  {
    "_id": ObjectId("695df3e910db6666ca9b52af"),
    "orderId": ObjectId("65c3c3c3c3c3c3c3c3c3c3c4"),
    "riderId": ObjectId("65b2f2b2b2b2b2b2b2b2b2b3"),
    "deliveryStatus": [
      { "status": "Processing", "timestamp": ISODate("2025-01-03T13:09:55.000Z") },
      { "status": "Picked Up", "timestamp": ISODate("2025-01-03T09:15:00.000Z") },
      { "status": "Out for Delivery", "timestamp": ISODate("2025-01-03T09:09:40.000Z") },
      { "status": "Delivered", "timestamp": ISODate("2025-01-03T10:05:00.000Z") }
    ],
    "currentStatus": "Delivered",
    "estimatedArrival": ISODate("2025-01-03T10:10:05.000Z")
  },
  {
    "_id": ObjectId("695e22a610db6666ca9b52e6"),
    "orderId": ObjectId("65c3c3c3c3c3c3c3c3c3c3c5"),
    "riderId": ObjectId("65b2f2b2b2b2b2b2b2b2b2b5"),
    "deliveryStatus": [
      { "status": "Processing", "timestamp": ISODate("2025-01-02T11:15:00.000Z") },
      { "status": "Picked Up", "timestamp": ISODate("2025-01-02T11:25:00.000Z") },
      { "status": "Out for Delivery", "timestamp": ISODate("2025-01-02T11:30:00.000Z") }
    ],
    "currentStatus": "Out for Delivery",
    "estimatedArrival": ISODate("2025-01-02T11:50:00.000Z")
  },
  {
    "_id": ObjectId("695e27fd10db6666ca9b52ea"),
    "orderId": ObjectId("65c3c3c3c3c3c3c3c3c3c3c6"),
    "riderId": ObjectId("65b2f2b2b2b2b2b2b2b2b2b6"),
    "deliveryStatus": [
      { "status": "Processing", "timestamp": ISODate("2025-01-06T09:15:00.000Z") },
      { "status": "Picked Up", "timestamp": ISODate("2025-01-06T09:25:00.000Z") },
      { "status": "Out for Delivery", "timestamp": ISODate("2025-01-06T09:30:00.000Z") },
      { "status": "Delivered", "timestamp": ISODate("2025-01-06T09:45:00.000Z") }
    ],
    "currentStatus": "Delivered",
    "estimatedArrival": ISODate("2025-01-06T09:45:00.000Z")
  }
]);

//riders collection
db.riders.insertMany([
  {
    "_id": ObjectId("65b2f2b2b2b2b2b2b2b2b2b2"),
    "riderName": "Muhammad Irfan",
    "phone": "0172233445",
    "vehicle": { "type": "Motorcycle", "plateNumber": "JQB 4321" },
    "isAvailable": true,
    "joinedDate": ISODate("2023-06-20T09:30:00.000Z")
  },
  {
    "_id": ObjectId("65b2f2b2b2b2b2b2b2b2b2b3"),
    "riderName": "Aiman Hakim",
    "phone": "0169988776",
    "vehicle": { "type": "Bicycle", "plateNumber": "N/A" },
    "isAvailable": true,
    "joinedDate": ISODate("2023-08-15T10:00:00.000Z")
  },
  {
    "_id": ObjectId("65b2f2b2b2b2b2b2b2b2b2b4"),
    "riderName": "Leonard Lee",
    "phone": "0182233441",
    "vehicle": { "type": "Motorcycle", "plateNumber": "JQR 9987" },
    "isAvailable": false,
    "joinedDate": ISODate("2024-01-10T08:45:00.000Z")
  },
  {
    "_id": ObjectId("65b2f2b2b2b2b2b2b2b2b2b5"),
    "riderName": "Nur Farah",
    "phone": "0191122334",
    "vehicle": { "type": "Car", "plateNumber": "JAB 1234" },
    "isAvailable": true,
    "joinedDate": ISODate("2024-03-05T09:15:00.000Z")
  }
]);