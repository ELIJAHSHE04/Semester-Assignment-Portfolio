// --- 1. INSERT OPERATIONS  ---

// 1.1 
db.riders.insertOne({
    riderName: "Siti Aminah",
    phone: "01122334455",
    vehicle: {
        type: "Motorcycle",
        plateNumber: "WXY 9876"
    },
    isAvailable: true,
    joinedDate: new Date()
});

// 1.2
db.customers.insertMany([
    {
        customerName: "Lau Yee Wen",
        email: "yeewen@email.com",
        phoneNumbers: ["0112223334", "0115556667"],
        address: {
            street: "Jalan Skudai 5",
            city: "Johor Bahru",
            state: "Johor",
            postcode: "81300"
        },
        registeredDate: new Date()
    },
    {
        customerName: "Poh Lok Yee",
        email: "polok@email.com",
        phoneNumbers: ["0178889990"],
        address: {
            street: "Persiaran Perling 2",
            city: "Iskandar Puteri",
            state: "Johor",
            postcode: "81200"
        },
        registeredDate: new Date()
    }
]);

// 1.3 
db.orders.insertMany([
    {
        _id: ObjectId("75c3c3c3c3c3c3c3c3c3c3c7"),
        customerId: ObjectId("75c3c3c3c3c3c3c3c3c3c3c7"), // Placeholder ID matching context
        items: [
            { itemName: "Nasi Kerabu", quantity: 1, price: 10.50 },
            { itemName: "Teh Tarik", quantity: 1, price: 2.00 }
        ],
        totalAmount: 13.00,
        payment: { method: "E-Wallet", status: "Paid" },
        orderDate: new Date()
    },
    {
        _id: ObjectId("75c3c3c3c3c3c3c3c3c3c3c8"),
        customerId: ObjectId("75c3c3c3c3c3c3c3c3c3c3c8"), // Placeholder ID
        items: [
            { itemName: "Chicken Chop", quantity: 2, price: 15.00 }
        ],
        totalAmount: 30.00,
        payment: { method: "Credit Card", status: "Paid" },
        orderDate: new Date()
    }
]);

// 1.4 
db.deliveries.insertMany([
    {
        orderId: ObjectId("75c3c3c3c3c3c3c3c3c3c3c7"),
        riderId: ObjectId("695e5ab2b0dbfdfe39603e7d"),
        deliveryStatus: [
            { status: "Processing", timestamp: new Date() }
        ],
        currentStatus: "Processing",
        estimatedArrival: new Date(new Date().getTime() + 30 * 60000) // +30 mins
    },
    {
        orderId: ObjectId("75c3c3c3c3c3c3c3c3c3c3c8"),
        riderId: ObjectId("65b2f2b2b2b2b2b2b2b2b2b5"),
        deliveryStatus: [
            { status: "Picked Up", timestamp: new Date() }
        ],
        currentStatus: "Picked Up",
        estimatedArrival: new Date(new Date().getTime() + 15 * 60000) // +15 mins
    }
]);


// --- 2. QUERY OPERATIONS 
// 2.1
db.riders.findOne({ riderName: "Muhammad Irfan" });

// 2.2
db.customers.find({ "address.city": { $eq: "Skudai" } });

// 2.3
db.orders.find({ totalAmount: { $gt: 15, $lt: 20 } });

// 2.4
db.customers.find({ customerName: { $in: ["Ng Yu Hin", "Lau Yee Wen"] } });

// 2.5
db.riders.find({
    $or: [
        { isAvailable: true },
        { "vehicle.type": "Motorcycle" }
    ]
});

// 2.6
db.orders.find({
    $and: [
        { totalAmount: { $gt: 15 } },
        { "payment.method": "E-Wallet" }
    ]
});

// 2.7 
db.orders.find({ "items.itemName": "Teh Tarik" });

// 2.8 
db.customers.find({}, { customerName: 1, email: 1, _id: 0 });


// --- 3. UPDATE OPERATIONS 

// 3.1
db.customers.updateOne(
    { customerName: "Lau Yee Wen" },
    { $set: { email: "yeewen_new@email.com" } }
);

// 3.2 
db.orders.updateMany(
    { totalAmount: { $gt: 20 } },
    { $inc: { totalAmount: 2 } }
);

// 3.3 
db.deliveries.updateOne(
    { _id: ObjectId("695e625231e3a5dfda151e58") },
    {
        $push: {
            deliveryStatus: {
                status: "Out for Delivery",
                timestamp: new Date()
            }
        },
        $set: { currentStatus: "Out for Delivery" }
    }
);

// 3.4 
db.customers.updateOne(
    { customerName: "Elijah She" },
    { $pull: { phoneNumbers: "0146282914" } }
);


// --- 4. DELETE OPERATIONS ---

// 4.1 
db.orders.deleteOne({ _id: ObjectId("75c3c3c3c3c3c3c3c3c3c3c6") });

// 4.2 
db.riders.deleteMany({ "vehicle.type": { $ne: "Motorcycle" } });


// --- 5. ADVANCED OPERATIONS ---

// 5.1 Indexing
db.orders.createIndex({ orderDate: 1 });
db.orders.getIndexes();

db.orders.createIndex({ customerId: 1, totalAmount: -1 });
db.orders.getIndexes();

// 5.2 Aggregation
db.orders.aggregate([
    {
        $group: {
            _id: "$payment.method",
            totalRevenue: { $sum: "$totalAmount" },
            count: { $sum: 1 }
        }
    },
    { $sort: { totalRevenue: -1 } }
]);

// 5.3 
db.deliveries.aggregate([
    { $match: { currentStatus: "Delivered" } },
    {
        $group: {
            _id: "$riderId",
            completedDeliveries: { $sum: 1 }
        }
    },
    { $project: { riderId: "$_id", completedDeliveries: 1, _id: 0 } }
]);

// 5.4 
db.orders.find().sort({ totalAmount: 1 });

// 5.5 
db.customers.find().sort({ registeredDate: -1 });